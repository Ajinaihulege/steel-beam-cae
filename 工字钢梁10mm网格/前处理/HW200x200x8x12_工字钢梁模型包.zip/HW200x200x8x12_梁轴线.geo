// Beam axis for 1D beam / line-mesh workflow, units mm
SetFactory("Built-in");
Mesh.MshFileVersion = 2.2;
Point(1) = {0, 0, 0, 100};
Point(2) = {2000, 0, 0, 100};
Point(3) = {4000, 0, 0, 100};
Line(1) = {1,2};
Line(2) = {2,3};
Physical Curve("left_half") = {1};
Physical Curve("right_half") = {2};
Mesh 1;
